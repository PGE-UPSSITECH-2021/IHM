import '../styles/ConnexionScreen.css'

function ConnexionScreen() {
	return (<div>
        <h2 className='pge-id-title'>Identification</h2>
        <div className='pge-id-champ'>
        <form className="login">
            <label className="label">
                Nom d'utilisateur :
                <input type="text" className="input-box" name="Nom d'utilisateur" autocomplete="off" />
            </label>
            <label className="label">
                Mot de passe :
                <input type="password" className="input-box" name="Nom d'utilisateur" />
            </label>
            <div>
                <span className='forgotten-mdp'>Mot de passe oublié ?</span>
                <button type="submit" className="input-button">Se connecter</button>
            </div>
        </form>
        </div>
        
    </div>)
}

export default ConnexionScreen