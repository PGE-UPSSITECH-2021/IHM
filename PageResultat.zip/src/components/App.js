import '../styles/App.css';
import TopBanner from './TopBanner'
import StateBanner from './StateBanner';
import ConnexionScreen from './ConnexionScreen';
import StateBannerUSR from './StateBannerUSR';
import MainScreenUSR from './MainScreenUSR';
import ResultScreen from './ResultScreen';

// function App() { // login screen
//  return (
//    <div>
//      <TopBanner />
//      <StateBanner />
//      <ConnexionScreen />
//    </div>
//  );
// }

function App() { // main screen Usr mode
    return (
        <div>
            <div className='topBanner'><TopBanner /></div>
            <div className='stateBanner'><StateBannerUSR /></div>
            <div className='mainResult'><ResultScreen /></div>
        </div>)
}

export default App;
