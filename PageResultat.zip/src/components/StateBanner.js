import '../styles/StateBanner.css'

function StateBanner() {
	return (<div className='pge-statebanner'>
    </div>)
}

export default StateBanner