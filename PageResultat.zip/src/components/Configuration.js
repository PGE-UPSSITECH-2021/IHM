﻿import '../styles/Configuration.css'
import React,{ useState } from 'react';
import { AiFillSafetyCertificate } from "react-icons/ai";
import { GiRobotGrab } from "react-icons/gi";

function Configuration() {
    const [rangeval, setRangeval] = useState(50);
    return (
        <div className="config">
            <h3>CONFIGURATION</h3>
            <button type="button" className="bouton-import">Importer une configuration</button>
            <div className='champ'><label className='labels'>Action :</label>
                <select>
                    <option selected disabled hidden>-----</option>
                    <option>Localiser la plaque</option>
                    <option>Identifier</option>
                    <option>Vérifier conformité</option>
                    <option>Déplacer le robot</option>
                </select>
            </div>
            <div className='champ'><label className='labels'>Type de plaque :</label>
                <select>
                    <option selected disabled hidden>-----</option>
                    <option>Tôle plate</option>
                    <option>Tôle cintrée</option>
                    <option>Tôle épaisse</option>
                </select>
            </div>
            <div className='champ'>
                <label className='labels'>Diamètre des trous :</label>
                <button type="button" className="bouton-select" >Sélectionner tous les diamètres</button>
                <div className='champCheck'>
                    <label>
                        <input type="checkbox"/>
                        5 mm
                    </label>
                    <label>
                        <input type="checkbox" />
                        7 mm
                    </label>
                    <label>
                        <input type="checkbox" />
                        12 mm
                    </label>
                    <label>
                        <input type="checkbox" />
                        18 mm
                    </label>
                </div>
            </div>
            <div className='champ-slider'>
                <div className='slider'><label className='labels'>Taux de confiance minimum :</label>
                    <span className='value'>{rangeval} %</span>
                    <br/><br/>
                    <input type="range" defaultValue="50" min="0" max="100" class="slider" id="myRange" step="1" onChange={(event) => setRangeval(event.target.value)}></input>
                    
                </div>
            </div>
            <button type="button" className="bouton-normal" >Sauvegarder</button>
            <button type="button" className="bouton-normal">Configuration par défaut</button>
            <button type="submit" className="bouton-run">Run</button>
            <div className='etat-courant'>
                <div className='etat'>
                    <GiRobotGrab className="icone"/>
                    Etat du robot :
                    <span className='rep'> LIBRE </span>
                </div>
                <div className='etat'>
                    <AiFillSafetyCertificate className="icone" />
                    Sécurité :
                    <span className='rep'> OK </span>
                </div>
            </div>
        </div>
    )
}

export default Configuration